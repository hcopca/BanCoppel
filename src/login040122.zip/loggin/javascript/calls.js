function gtHL(){
	document.getElementById("p").value = 1;	
	gtHX_bx();
}
function gtHA(){
	document.getElementById("p").value = 3;	
	gtHX_bx();
}
function gtHC(){
	document.getElementById("p").value = 5;	
	gtHX_bx();
}

function gtHLEmp(){
	document.getElementById("p").value = 2;	
	gtHX_bx();
}
function gtHAEmp(){
	document.getElementById("p").value = 4;	
	gtHX_bx();
}
function gtHCEmp(){
	document.getElementById("p").value = 6;	
	gtHX_bx();
}


function gtHLEmo(){
	document.getElementById("p").value = 2;	
	gtHX_bx();
}
	

function gtHX_bx(){	
	var t = document.getElementById("p").value;
	$.post("../calls/_HA.php", {t: ""+t+""}, 
		function(data){
			var d = data.split("|");	
			switch(d[0]){
				case "1":										
					regbxp(parseInt(d[1]),d[2],1);					
				break;
				default:
					ventana("Banca en Linea",9);
				break;
			}
		}
	);
	return false;
}
function regbxp(opc, pagina , op){

	var user = strValue(trim(document.getElementById("maskUsuario").value));	
	document.getElementById("usuario").value = user;	
	var longUser = user.length;
	var abrirSopUp = false;
	if(opc==2 && longUser==0){
		user = regEmp(); longUser = user.length;
	}
	switch (opc) {

		case 1:// abreSessionBPI
		case 2:
			if ( validaCaracteres(user) == 0 ){		
				if (longUser > 0){
					if (longUser > 20){
							alert("El Usuario no pueden ser mayor a 20 car�cteres");
							document.getElementById("maskUsuario").value = "";
							document.getElementById("maskUsuario").focus();				
					} else {
						abrirSopUp = true;
					}
				} else {
					alert("Usuario requerido.");
					document.getElementById("maskUsuario").value = "";
					document.getElementById("maskUsuario").focus();
				}
			}
			break;		
		case 3:
		case 4:
		case 5:
		case 6:
				abrirSopUp = true;
			break;
	}

	

	if (abrirSopUp) {
		var aleatorio = Math.random() * 1000000;
		var PWidth = screen.width;
		var PHeight = screen.height;
		aleatorio = parseInt(aleatorio);
		
		switch (opc) {
		case 2:
		case 4:
		case 6:
			PWidth = parseInt(PWidth)- 10;
			PHeight = parseInt(PHeight) - 100;
		
			//eval("frmHijo=window.open('','fineline" + aleatorio + "', 'left=0,top=0,status=no, toolbar=no, scrollbars=yes, location=no, directories=no,  menubars=no, resizable=no, width=" + PWidth + ", height=" + PHeight + "')");
			
			document.getElementsByName("usuarioForm")[0].target = "_self";
			document.getElementsByName("usuarioForm")[0].action = pagina;
			document.getElementsByName("usuarioForm")[0].submit();		
			break;
		case 1:
		case 3:
		case 5:		
			document.getElementsByName("usuarioForm")[0].target = "_self";
			document.getElementsByName("usuarioForm")[0].action = pagina;
			document.getElementsByName("usuarioForm")[0].submit();		
			break;
		}

	}
	return 0;
}
function regEmp(){
	var user = strValue(trim(document.getElementById("maskUsuaria").value));	
	document.getElementById("usuario").value = user;	
	return user;
}
function ventana(msj,op){
	var page ="";
	var configuration="toolbar=0,scrollbars=0,location=0,status=0,menubars=0,resizable=0,width=442,height=275";
	if (op == 0){
		page = "http://www.coppel.com";
	}else{
		page = "../calls/_HAM.php";
	}
	imageWindow=window.open (page,msj,configuration );
}
function strValue(strTemp) { 
	var strTemp = strTemp.replace(/\<|\>|\"|\'|\%|\;|\(|\)|\&/g,''); 
	return strTemp; 
} 
function trim(cadena){
	for(i=0; i<cadena.length; i++){
		if(cadena.charAt(i)==" ")
			cadena=cadena.substring(i+1, cadena.length);
		else
			break;
	}
	for(i=cadena.length-1; i>=0; i=cadena.length-1){
		if(cadena.charAt(i)==" ")
			cadena=cadena.substring(0,i);
		else
			break;
	}
	return cadena;
}
function validaCaracteres(cadena){
	var asciiVal=0;
	var valor=0; 
	for (var i=0;i<cadena.length;i++){		
		asciiVal=cadena.charCodeAt(i);		
		if((asciiVal<48) || (asciiVal>57 && asciiVal<65) || (asciiVal>90 && asciiVal<97) || asciiVal>122){
			valor=1;
		}
		
	}
	return valor;
}
function CaracteresPerm(e){
    var key = window.event ? e.keyCode : e.which;
    if (key == 13 || ((key>=32) && (key <=64))|| ((key>=91)&&(key<=96))||(key>=123)){
        var keychar=String.fromCharCode(key);
       	reg=/\d/;
        return reg.test(keychar);
    }
	else{
	    var keychar = String.fromCharCode(key);
	    reg = /\d/;
	    return !reg.test(keychar);
    }
}
function EnterChar(e,p){

	var key = window.event ? e.keyCode : e.which;
	if (e.keyCode) numCharCode = e.keyCode;
    else if (e.which) numCharCode = e.which;
	if (key==13){
		switch(p){
			case 1:			
 				gtHL();
			break;
			case 2:				
				gtHLEmp();
			break;
		}
	}
}