<?php
	//require_once("cnxbancoppel.inc");
 	$est = (isset($_POST['t'])?seguridad_var(htmlentities($_POST['t'])):0);
	$urlBancaEnLinea = '';
	$resp = 0 ; 
	if(is_numeric($est)){	
		$resp = true;		
		if ($resp==true && $est > 0){
			switch($est){
				case 1:
					$urlBancaEnLinea = getUrlBancaBPI()."frmAvatarLogin.go";
					break;					
				case 2:	
					$urlBancaEnLinea = getUrlBancaENet()."frmLogin.go";
					break;
				case 3:
					$urlBancaEnLinea = getUrlBancaBPI()."frmActivacion.go";					
					break;
				case 5:
					$urlBancaEnLinea = getUrlBancaBPI()."frmReactivacion.go";					
					break;		
				case 4:	
					$urlBancaEnLinea = getUrlBancaENet()."frmActivacion.go";
					break;
				case 6:	
					$urlBancaEnLinea = getUrlBancaENet()."frmReactivacion.go";
					break;
			}	
			$resp ="1|".$est."|".$urlBancaEnLinea;
		}else{
			$resp=0;
		}
	}else{
		$resp = -1;
	}
	echo $resp;
?>
<?php
 function getUrlBancaBPI(){
   return "https://www.bancoppel.com/BanCoppelWeb/";
 }
 function getUrlBancaENet(){
   return "https://www.bancoppel.com/EmpresaNetWeb/";
 }
 function seguridad_var($texto){ 
		  $texto = stripslashes($texto); 
		  $texto = addslashes($texto); 
		  $texto= str_replace(";","",$texto); 
		  $texto= str_replace("<","",$texto); 
		  $texto= str_replace(">","",$texto); 
		  $texto= str_replace("/","",$texto); 
		  $texto= str_replace(":","",$texto);
		  $texto= str_replace("SELECT","",$texto); 
		  $texto= str_replace("FROM","",$texto); 
		  $texto= str_replace("WHERE","",$texto); 		  
		  return $texto; 
	}
?>
